def receive(text):
    print('正在接收 %s' % text)